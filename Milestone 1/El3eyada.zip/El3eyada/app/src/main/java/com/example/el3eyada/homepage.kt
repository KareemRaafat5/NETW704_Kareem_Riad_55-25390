package com.example.el3eyada

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.el3eyada.databinding.ActivityHomepageBinding

class homepage : AppCompatActivity() {
    private lateinit var binding: ActivityHomepageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityHomepageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.profilebutton.setOnClickListener{
            val intent = Intent(this,profile::class.java)
            startActivity(intent)
        }
        binding.mapbutton.setOnClickListener{
            val intent = Intent(this, maps::class.java)
            startActivity(intent)
        }
        binding.logoutbutton.setOnClickListener{
            val intent = Intent(this, login::class.java)
            startActivity(intent)
            finish()
        }

    }
}