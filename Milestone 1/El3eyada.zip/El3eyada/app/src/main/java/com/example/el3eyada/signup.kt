package com.example.el3eyada

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.el3eyada.databinding.ActivityLoginBinding
import com.example.el3eyada.databinding.ActivitySignupBinding
import com.google.firebase.auth.FirebaseAuth

class signup : AppCompatActivity() {
    private lateinit var binding: ActivitySignupBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        binding.signupButton.setOnClickListener{
            val email = binding.signupEmail.text.toString()
            val password = binding.signupPassword.text.toString()
            val confirm = binding.signupConfirm.text.toString()

            if(email.isNotEmpty() && password.isNotEmpty() && confirm.isNotEmpty()){
                if(password == confirm ){
                    firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener{
                        if (it.isSuccessful){
                            Toast.makeText(this,"Account created successfully",Toast.LENGTH_SHORT).show()
                            val intent = Intent(this,login::class.java)
                                startActivity(intent)
                        }else {
                            Toast.makeText(this,it.exception.toString(),Toast.LENGTH_SHORT).show()
                        }
                    }
                }else{
                    Toast.makeText(this,"password mismatch",Toast.LENGTH_SHORT).show()
                }
            }else{
                Toast.makeText(this,"Please fill the missing fields",Toast.LENGTH_SHORT).show()
            }



        }
        binding.loginRedirectText.setOnClickListener{
            val loginintent = Intent(this,login::class.java)
            startActivity(loginintent)
        }

    }
}