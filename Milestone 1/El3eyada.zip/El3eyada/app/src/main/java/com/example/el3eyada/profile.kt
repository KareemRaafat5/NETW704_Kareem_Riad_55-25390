package com.example.el3eyada

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.el3eyada.databinding.ActivityLoginBinding
import com.example.el3eyada.databinding.ActivityProfileBinding


class profile : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)


        // Retrieve saved email and password
        val sharedPreferences = getSharedPreferences("UserPreferences", Context.MODE_PRIVATE)
        val email = sharedPreferences.getString("email", "No email")
        val password = sharedPreferences.getString("password", "No password")
        val extraInfo = sharedPreferences.getString("extraInfo", "")

        // Display email and password
        binding.viewemail.text = "Email: $email"
        binding.viewpassword.text = "Password: $password"
        binding.moreinfo.setText(extraInfo)

        // Save extra info on button click
        binding.savebtn.setOnClickListener {
            val newExtraInfo = binding.moreinfo.text.toString()

            val editor = sharedPreferences.edit()
            editor.putString("extraInfo", newExtraInfo)
            editor.apply() // Save extra info
        }
        binding.backtn.setOnClickListener{
            val intent = Intent(this,homepage::class.java)
            startActivity(intent)
        }






    }
}